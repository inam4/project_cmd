﻿using System;
using System.Collections.Generic;
using System.Data;
using Web_API.Data_Layer;
using Web_API.Models;

namespace Web_API.BusinessLayer
{
    public class CommentsBusinessLayer
    {
        public CommentsDL dataLayer = new CommentsDL();
        public List<Comments> GetComments()
        {
            try
            {
                DataTable table = new DataTable();
                List<Comments> listsComments = new List<Comments>();
                table = dataLayer.GetComments();

                if (table != null && table.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in table.Rows)
                    {
                        Comments comment = new Comments();
                        comment.PostId = Convert.ToInt32(dataRow["PostId"]);
                        comment.CommentsId = Convert.ToInt32(dataRow["CommentsId"]);
                        comment.UserId = Convert.ToInt32(dataRow["UserId"]);
                        comment.Content = dataRow["Content"].ToString();

                        listsComments.Add(comment);
                    }
                }
                return listsComments;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfStudents due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public string InsertComments(Comments comment)
        {
            try
            {
                string response = dataLayer.InsertCommentsInDB(comment);
                return response;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in InsertStudent due to "
                   + exception.Message, exception.InnerException);
            }
        }
    }
}