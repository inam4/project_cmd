﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API.BusinessLayer;
using Web_API.Models;

namespace Web_API.Controllers
{



    public class PostsController : ApiController
    {
        public PostsBL posts_dataLayer = new PostsBL();

        // GET api/<controller>
        [HttpGet]
        [Route("GetPosts")]
        public List<Posts> GetPosts()
        {
            try
            {
                List<Posts> posts = new List<Posts>();
                posts = posts_dataLayer.GetPosts();
                return posts;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfStudents due to "
                   + exception.Message, exception.InnerException);
            }
        }


        [HttpPost]
        [Route("InsertPosts")]
        public string InsertPosts(Posts post)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    string resposne = posts_dataLayer.InsertPosts(post);
                    if (!string.IsNullOrEmpty(resposne))
                    {
                        return "Student Added Successfully!";
                    }
                    else
                    {
                        return "Student Not Added Successfully!";
                    }
                }
                else
                {
                    return "Model Is Not Valid";
                }
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in InsertStudent due to "
                   + exception.Message, exception.InnerException);
            }
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}