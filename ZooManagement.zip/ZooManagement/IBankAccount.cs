﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagement
{
    interface IBankAccount  //the class that inherits from interface class must have methods mentioned.
    {
        void Deposit(double amount);
        void Withdraw(double amount);

    }
}
