﻿using System;
using System.Collections.Generic;



namespace BankManagement
{
    class Program
    {
        static void Main(string[] args)

        {
            Bank bank = new Bank();

            SavingsAcccount s_acc = new SavingsAcccount("Zain", 1, 98000, 12);
            CheckingAcccount c_acc = new CheckingAcccount("Osama", 2, 100000);
            s_acc.Deposit(500);
            BankAccount[] bank_accounts = { s_acc, c_acc };
            
            // s_acc.ExecuteTransaction(500, "Deposit");
            // Console.WriteLine("---------------------------------Saving Account-------------------------------");
            bank.AddAccount(s_acc);
            bank.AddAccount(c_acc);
       
            Console.WriteLine();
            bank.DepositToAccount(c_acc, 2000);
            Console.WriteLine();
            bank.WithdrawFromAccount(s_acc, 5000);
            // bank.WithdrawFromAccount(s_acc, 10000);
            Console.WriteLine("YO");
            Console.WriteLine("---------------------------------Checking Account-------------------------------");
            Console.WriteLine();
            bank.DepositToAccount(c_acc, 2000);
            Console.WriteLine();
            bank.WithdrawFromAccount(c_acc, 5000);
            bank.C_Transaction_History();


        }
    }
}

    


