﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagement
{
    //interface ITransaction
    //{
    //    void ExecuteTransaction(double amount, string transaction_type);
    //    void PrintTransaction(double amount, string transaction_type);
    //}
    public class Transaction
    {
        public List<double> Deposit_List;
        public List<double> Withdraw_List;
        public Dictionary<string, List<double>> t_history;

      
        public Transaction()
        {
            Deposit_List = new List<double>();
            Withdraw_List = new List<double>();
            t_history = new Dictionary<string, List<double>>();
            t_history.Add("Deposit", Deposit_List);
            t_history.Add("Withdraw", Withdraw_List);
        }
        

        public void Deposit_T(double Amount_Add)
        {
    
            Deposit_List.Add(Amount_Add);
        }

    

        public void Withdraw_T(double DEL)
        {
            Withdraw_List.Add(DEL);

        }

    }
    
}
