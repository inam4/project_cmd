﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagement
{
    public abstract class BankAccount : IBankAccount
    {
        private string name;
        protected int accountnumber;
        protected double balance;
        public string Account_type;
        public Transaction t;
        public string Name
        {
            get { return name; }
            set { name = value; }

        }

        public int AccountNumber
        {
            get { return accountnumber; }
            set { accountnumber = value; }
        }

        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }
        public BankAccount(string name, int acc_number, double balance, string account_type)
        {
            //Initialising so that they can be used within classes inherited.
            Name = name;
            AccountNumber = acc_number;
            Balance = balance;
            Account_type = account_type;
            t = new Transaction();
          
            



        }

        public virtual void Deposit(double Amount_Add)
        {
            t.Deposit_T(Amount_Add);
            Balance = Balance + Amount_Add;
            Console.WriteLine($"{Name}'s Account with ID {AccountNumber} credited with amount {Amount_Add} ");
            Console.WriteLine($"New Balance is PKR{Balance}");
            
        }

        public virtual void Withdraw(double DEL)
        {
            t.Withdraw_T(DEL);
            Balance = Balance - DEL;
            Console.WriteLine($"{Name}'s Account with ID {AccountNumber} decredited with amount {DEL} ");
            Console.WriteLine($"New Balance is PKR{Balance}");
         
           
        }

        public abstract void DisplayAccountInfo();

        public virtual double CalculateInterest(double interest)
        {
            return interest;
        }

        
    }

}
