﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagement
{
    public class Bank
    {
        public List<BankAccount> Customer_Account;
        public Dictionary<int, Dictionary<string,List<double>>> Customer_Transaction_History;

        public Bank()
        {

            Customer_Account = new List<BankAccount>();
            Customer_Transaction_History = new Dictionary<int, Dictionary<string, List<double>>>();
        }

        public void AddAccount(BankAccount bank_account)
        {
            Customer_Account.Add(bank_account);
            Customer_Transaction_History.Add(bank_account.AccountNumber, bank_account.t.t_history);
            bank_account.DisplayAccountInfo();
        }

        public void DepositToAccount(BankAccount bank_account, double Amount_Add)
        {
            bank_account.Deposit(Amount_Add);

        }

        public void WithdrawFromAccount(BankAccount bank_account, double Amount_DEL)
        {

            bank_account.Withdraw(Amount_DEL);

        }
        public void CheckAccount(BankAccount bank_account)
        {

            bank_account.DisplayAccountInfo();

        }

        public void C_Transaction_History()
        {
            foreach (var item in Customer_Transaction_History)
            {
                Console.WriteLine($"Transaction History of Account Number {item.Key}");
                foreach (var item2 in item.Value)
                {
                    Console.WriteLine($"Transaction Type: {item2.Key}");
                    foreach (double item3 in item2.Value)
                    {
                        Console.WriteLine($"Amount: {item3}");
                    }
                }
            }
        }
    }
}
