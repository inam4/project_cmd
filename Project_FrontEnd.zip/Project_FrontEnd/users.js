function submit_post_Function()
{   
    var email = document.getElementById("signup-email");
    var user = document.getElementById("signup-name");
    var password = document.getElementById("signup-password");
    
    var settings = {
        "url": "http://localhost:19804/GetUsers",
        "method": "GET",
        "timeout": 0,
      "headers": {
        "Content-Type": "application/json"
      },
      };
      
      $.ajax(settings).done(function (response)
       {
        dict = response;
        var len = dict.length;
        var is_exist = false;
        for(let i=0;i<dict.length;i++)
        {
           if(email.value==response[i]["Email"])
           {
            alert("User Already Exist");
            is_exist=true;
           }
        }
        if(is_exist==false)
        {
            alert("User Registered");
            var settings = {
                "url": "http://localhost:19804/InsertUsers",
                "method": "POST",
                "timeout": 0,
                "headers": {
                  "Content-Type": "application/json"
                },
                "data": JSON.stringify({
                  "Name": user.value,
                  "Email": email.value,
                  "Password": password.value
                }),
              };
              
                $.ajax(settings).done(function (response) {
                console.log(response);
              });
        }

      });

}



function submit_user_Function()
{
    var email = document.getElementById("email");
    var password = document.getElementById("password");
    var settings = {
        "url": "http://localhost:19804/GetUsers",
        "method": "GET",
        "timeout": 0,
      "headers": {
        "Content-Type": "application/json"
      },
      };
      
      $.ajax(settings).done(function (response)
       {
        dict = response;
        var len = dict.length;
        var is_exist = false;
       
        for(let i=0;i<dict.length;i++)
        {
          
           
           if(email.value==dict[i]["Email"] && password.value==dict[i]["Password"] )
           {
            alert("Log ON successful");
            window.location.assign = "http://127.0.0.1:5500/Front_page.html"; 
            is_exist=true;
           }
        }
        if(is_exist==false)
        {
            alert("Password or Email incorrect");
        }
      });



}