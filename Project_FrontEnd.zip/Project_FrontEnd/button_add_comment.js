$(document).ready(function() {
const button1 = document.getElementById("add_value");
button1.addEventListener("click",function()
{   
    alert("eS");
    
  
    
});

});
