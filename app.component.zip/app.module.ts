import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from "./home/home.component";
import { HousingLocationComponent } from './housing-location/housing-location.component';
import { RouterModule } from '@angular/router';
import { DetailsComponent } from './details/details.component';


@NgModule({
    declarations: [
        AppComponent,
        
        
    ],
    providers: [],
    bootstrap: [AppComponent],
    imports: [
        BrowserModule,
        HomeComponent,
        HousingLocationComponent,
        RouterModule.forRoot([
          {path: '', component: HomeComponent},
          {path: 'homes/:id', component: DetailsComponent},
        ]),
        
    ]
})
export class AppModule { }
