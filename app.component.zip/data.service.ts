export const data = [
    {
      ID: 1,
      Title: 'Samaria',
      Content: 'asdd',
      Display: "block",
      Checked:false,

    },
    {
      ID: 2,
      Title: 'Gauthier',
      Content: 'asdd',
      Display: 'block',
      Checked:false,


    },
    
  ];
  
  
  export const data2 = [
    {
      ID: 1,
      Title: 'inam',
      Display: true,
      Checked:true,

    },
    {
      ID: 2,
      Title: 'aqr',
      Display: true,
      Checked:true,
    },
  ];