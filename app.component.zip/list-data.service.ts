import { Injectable } from '@angular/core';
import { DataInterface } from './data-interface';
import { HttpClient } from '@angular/common/http';
import { Data } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class ListDataService {

  users:DataInterface[]=[];
  users2:DataInterface[]=[];
  
  constructor(private http:HttpClient)
  {

  }
  get_active_data()
  {
    return this.http.get('http://localhost:53424/GetUsers/GetActiveList');   
  }
  get_inactive_data()
  {
    return this.http.get('http://localhost:53424/GetUsers/GetInActiveList');   
  }
  set_users(u:any):DataInterface[]{
    this.users=u;
    return this.users;
  }
  set_inactive_users(u:any):DataInterface[]{
    this.users2=u;
  
    return this.users2;
  }
//   get_data(u:DataInterface[]):void{
// // this.users=u;    
// //     console.log(this.users[1].Checked);

//   }

  Edit_Display(i:number):void{
    this.users[i].Display='none';
  }
  Edit_Display_2(i:number):void{
    this.users2[i].Display='none';
  }
  Update_change(i:number,value:any,description:any):void
  {
    this.users[i].Display='block';
      this.users[i].Title = value;
      this.users[i].Content=description;
      this.users[i].Checked = false;
  }

  getDataListUsers(): DataInterface[]{
   return this.users;
  }

  getDataUser(i:number): DataInterface{
    return this.users[i];
   }

   getDataUser2(i:number): DataInterface{
    return this.users2[i];
   }

  addDataListUsers(title:string,description:string,Display:string,Checked:boolean):void
  {
    this.users.push({
      Title: title,
      Content: description,
      Display: "block",
      Checked: false,
    });
  }
  addDataListUsers1(data:any):void
  {
    this.users.push(data);
  }
  DeleteListUsers(i:number):void
  {
    this.users.splice(i,1);
  }

  getDataListUsers2(): DataInterface[]{
    return this.users2;
   }
 
   addDataListUsers2(data:DataInterface):void
   {
     this.users2.push(data);
   }
 
   DeleteListUsers2(i:number):void
   {
     this.users2.splice(i,1);
   }

   Update_change_2(i:number,value:any,description:any):void
  {
    this.users[i].Display='block';
      this.users[i].Title = value;
      this.users[i].Content =description;
      this.users[i].Checked = true;
  }

}
