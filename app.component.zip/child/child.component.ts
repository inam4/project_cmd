import { Component ,Input,OnDestroy,OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {Validator,FormsModule, ReactiveFormsModule} from "@angular/forms"
import {MatRadioModule} from '@angular/material/radio';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatCardModule} from '@angular/material/card';
import { ListDataService } from '../list-data.service';
import { DataInterface } from '../data-interface';
@Component({
  selector: 'app-child',
  standalone: true,
  imports: [CommonModule, MatCheckboxModule, MatCardModule, MatRadioModule, FormsModule, ReactiveFormsModule, MatButtonModule, MatIconModule, MatInputModule, MatFormFieldModule, BrowserAnimationsModule,],
  template: `
    <div [style.Displaylay]="user_component.Display">
        <div>{{ user_component.Title }}</div>
        <div>{{ user_component.Content }}</div>

        <mat-checkbox type="checkbox" [ngModel]="user_component.Checked" [name]="'check-' + index_i" #check="ngModel"
          [id]="'check-' + index_i" (change)="Checked(index_i)"></mat-checkbox>

        <button (click)="DeleteButton(index_i)">DELETE</button>
        <button (click)="Update_button(index_i)">UPDATE</button>
      </div>

      <div *ngIf="user_component.Display === 'none'">
        <form>
          <input ngModel [name]="'input-' + index_i" #control="ngModel"  [id]="'input-' + index_i" />
          <input ngModel [name]="'input-1-' + index_i" #control_box_1="ngModel" [id]="'input_box-' + index_i" />

          <button (click)="update_change(index_i, control.value, control_box_1.value)">
            update
          </button>
        </form>
      </div>
  `,
  styleUrls: ['./child.component.css'],
 
})
export class ChildComponent implements OnInit,OnDestroy
{
  constructor(private dataService: ListDataService) {}


  @Input() user_component: any;
   @Input() index_i:any;
   timer_value:number =0;

   interval: any;
  counter = 0;
  ngOnInit(): void
  {
    this.interval = setInterval(() =>{
      this.counter=this.counter+1;
    },1000
    )
  }
  
  ngOnDestroy(): void {
    throw new Error('Method not implemented.');
  }
  user_to_edit: DataInterface | undefined;

  Checked(i:number)
  {  
    this.user_to_edit=this.dataService.getDataUser(i);
    this.user_to_edit.Checked=true;
    this.dataService.addDataListUsers2(this.user_to_edit);
    this.dataService.DeleteListUsers(i);
      
  }

  DeleteButton(i:number):void{
    this.dataService.DeleteListUsers(i);

  }
  
   
  Update_button(i:number):void{
    this.dataService.Edit_Display(i);
  }

  update_change(i:number,value:any,description:any)
  {   
      this.dataService.Update_change(i,value,description);

  }

}
