import { Component,OnInit } from '@angular/core';
import { DataInterface } from './data-interface';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import {FormGroup,FormBuilder, Validators} from "@angular/forms"
import { ListDataService } from './list-data.service';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  users:DataInterface[]=[];
  users2:DataInterface[]=[];
  constructor(private dataService: ListDataService) 
  {
    dataService.get_active_data().subscribe((data)=>this.users=dataService.set_users(data));
    dataService.get_inactive_data().subscribe((data)=>this.users2=dataService.set_inactive_users(data));

    console.log(this.users);
  }

  // ngOnInit(): void 
  // {
  //   console.log('ng');
  //   this.http.get<DataInterface[]>('http://localhost:12586/GetUsers').subscribe(
  //     (users1) => {
        
  //       this.dataService.get_data(users1);
  //       console.log(users1);
  //     }
  //   );
    
  // }
  get_data():void{
    // this.http.get<DataInterface[]>('http://localhost:12586/GetUsers').subscribe(
    //   (users1) => {
        
    //     this.dataService.get_data(users1);
    //   }
    // );

  }
  
  log1():void
  {
    console.log("PSO")
  }

  drop1(event: CdkDragDrop<DataInterface[]>): void {
    console.log(event.item.data);

    if (event.previousContainer !== event.container) {
    }
    // moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    transferArrayItem(
      event.previousContainer.data, 
      event.container.data,       
      event.previousIndex,        
      event.currentIndex            
    );
  }

  drop(event: CdkDragDrop<DataInterface[]>): void {
    transferArrayItem(
      event.previousContainer.data, // Source array
      event.container.data,         // Destination array
      event.previousIndex,          // Index in the source array
      event.currentIndex            // Index in the destination array
    );
  }

  AddButton(title:string,description:string): void {
   
    this.dataService.addDataListUsers(title,description,"block",false)
   
  }
  
  DeleteButton(i:number):void{
    this.dataService.DeleteListUsers(i);
  }
  

  DeleteButton_2(i:number):void{
    this.dataService.DeleteListUsers2(i);
  }
  
  Update_button(i:number):void{
    this.dataService.Edit_Display(i);
  }

  Update_button_2(i:number):void{
    this.dataService.Edit_Display_2(i);
  }

  log(logout: any)
  {
    console.log(logout);
  }
  update_change_2(i:number,value:any,description:any)
  {   
      this.dataService.Update_change_2(i,value,description);

  }

  user_to_edit: DataInterface | undefined;

  unchecked(i:number)
  {   
    this.user_to_edit = this.dataService.getDataUser2(i)
    this.user_to_edit.Checked=false;
    this.dataService.addDataListUsers1(this.user_to_edit)
    this.dataService.DeleteListUsers2(i);
  }
}




