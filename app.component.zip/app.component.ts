import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template: `
  <main>
    <header class="brand-name">
      <img class="brand-logo" src="favicon.ico" alt="logo" aria-hidden="true">
    </header>
    <section class="content">
      <router-outlet></router-outlet>
    </section>
  </main>
`, 
 styleUrls: ['./app.component.css'],
//  directives: [HomeComponent ]
})
export class AppComponent {
  title = 'Homes';
}

