$(document).ready(function() {
    var dict = {};
    $.ajax({
        url: "http://localhost:3013/GetPosts",
        type: "GET",
        datatype: "json",
        success: function(data) {
            dict = data;
            post_list = document.getElementById("blogs-content")
            var end_item = data.length;
            for (let k = 0; k < end_item; k++) 
            {
                var tmp = '<span class="blog-edit" id="blog-edit-'+dict[k]["PostsId"]+'">Edit</span>' +
                '<div class="blog-Delete" id="blog-Delete-'+dict[k]["PostsId"]+'">Delete</div>' +
                '<span class="blog-title" id="blog-title-'+dict[k]["PostsId"]+'">'+dict[k]["Title"]+'</span>' +
                '<div class="blog-date" id="blog-date-'+dict[k]["PostsId"]+'">Posted on July 31, 2023</div>' +
                '<div class="blog-content" id="blog-content-'+dict[k]["PostsId"]+'">' +
                dict[k]["Content"] +
                '</div>' +
                '<input type="button" name="button_click" value="Add Comment" class="blog-add-comments" id="add_comment_'+dict[k]["PostsId"]+'" onclick=clickFunction('+dict[k]["PostsId"]+')> '+
                '<input type="button" class="blog-view-comments" value="View Comments" id="blog-view-comments-'+dict[k]["PostsId"]+'" onclick=View_Comment_Function('+dict[k]["PostsId"]+')> ' ;
                
                var tr = document.createElement('div');
                tr.className = "blog-post";
                tr.id="blog-post-id-"+dict[k]["PostsId"];
                tr.innerHTML = tmp;
                post_list.appendChild(tr);
               


            }

        },
        error: function(error) {

        }
    });
});

