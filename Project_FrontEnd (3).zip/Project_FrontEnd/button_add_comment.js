

function clickFunction(buttonid) {

 

    var name = document.getElementById("blog-content-" + buttonid);
    var temp = '<input type="text" id="comment_box_'+buttonid+'" name="comment_box" value="Enter Comment"><br><input type="submit" onclick=submit_Comment_Function('+buttonid+') id="comment_box_'+buttonid+'" value="Submit">';
    var foam = document.createElement('div');
    foam.id= "comment_div_box_id_"+buttonid;
    foam.innerHTML = temp;
    name.insertAdjacentElement('afterend',foam);
    var element = document.getElementById('add_comment_'+buttonid);
    element.style="display:none";

  }


  function submit_Comment_Function(buttonid) 
  {
    post_list = document.getElementById("blog-view-comments-"+buttonid)
  if(post_list.value=="Hide Comments")
  {  var element = document.getElementById("comments_list_"+buttonid);
      if (typeof(element) != 'undefined' && element != null)
    {
      element.style="display:none";
      post_list.value="View Comments";
    }
   
  }
    var inputElement = document.getElementById('comment_box_' + buttonid);
    var commentValue = inputElement.value;

    var settings = {
      "url": "http://localhost:3013/InsertComments",
      "method": "POST",
      "timeout": 0,
      "headers": {
        "Content-Type": "application/json"
      },
      "data": JSON.stringify({
        "PostId": 2,
        "UserId": 1,
        "Content": commentValue
      }),
    };
    
    $.ajax(settings).done(function (response) {
      console.log(response);
    });


    var element_1= document.getElementById("comment_div_box_id_"+buttonid);
    var element_1_parent = element_1.parentNode;
    element_1_parent.removeChild(element_1);

    var element = document.getElementById('add_comment_'+buttonid);
    element.style="display:inline";
  }



function View_Comment_Function(buttonid)
{
  post_list = document.getElementById("blog-view-comments-"+buttonid)
  post_list.style="display:inline";
  if(post_list.value=="View Comments")
  {
    var settings = {
      "url": "http://localhost:3013/GetComments",
      "method": "GET",
      "timeout": 0,
      "headers": {
        "Content-Type": "application/json"
      },
    };
    post_list.value="Hide Comments";
    var comments_list_1=document.createElement('div');
    comments_list_1.id="comments_list_"+buttonid;

    $.ajax(settings).done(function (response) {
        dict = response;
        comments_list = document.getElementById("blogs-content")
        var end_item = dict.length;

        for (let k = 0; k < end_item; k++) 
        {
          if(dict[k]["PostId"]==buttonid)
          {var tmp = 
            '<span class="comment_name" id="blog-title-'+dict[k]["CommentsId"]+'">'+dict[k]["UserId"]+':  </span>' +

            '<span class="comment-box" id="comment-box-id-'+dict[k]["CommentsId"]+'">'+dict[k]["Content"]+'</div>';
            
            var tr = document.createElement('div');
            tr.className = "post_comment";
            tr.id="post_comment-id-"+dict[k]["CommentsId"];
            tr.innerHTML = tmp; 
            comments_list_1.appendChild(tr);
          }
              }
              post_list.insertAdjacentElement('afterend',comments_list_1);

  
    });
  }
  else if(post_list.value=="Hide Comments")
  {
    var element = document.getElementById("comments_list_"+buttonid);
    element.style="display:none";
    post_list.value="View Comments";
  }
  
}

function add_content(id)
{
  alert(id);
  var name = document.getElementById(id);
    var temp = '<input type="text" id="content_title_'+id+'" name="content_title" value="Enter Title"><br><input type="text" id="content_body_'+id+'" name="content_body" value="Enter Content"><br><input type="submit" onclick=submit_post_Function('+id+') id="content_box_'+id+'" value="Submit">';
    var foam = document.createElement('div');
    foam.id= "content_add_box_"+id;
    foam.innerHTML = temp;
    name.insertAdjacentElement('afterend',foam);

  
}



function submit_post_Function(id)
{ alert(id.id);
  var inputElement = document.getElementById('content_title_'+id.id);
  var contentValue = inputElement.value;
  var titleElement = document.getElementById('content_body_'+id.id);
  var titleValue = titleElement.value;
  $("#"+"content_add_box_"+id.id).remove();

  var settings = {
    "url": "http://localhost:3013/InsertPosts",
    "method": "POST",
    "timeout": 0,
    "headers": {
      "Content-Type": [ "application/json"]
    },
    "data": JSON.stringify({
      "Title": titleValue,
      "UserId": 1,
      "Content": contentValue
    }),
  };
  
  $.ajax(settings).done(function (response) {
    console.log(response);
  });
}
// var element =  document.getElementById(buttonid);
//     if (typeof(element) != 'undefined' && element != null)
//     {
       
      
//         var doc = document.getElementById("add_name");
//         var num_add = document.getElementById("add_num");
//         var temp = '<td>'+ doc.value + '</td><td>'+num_add.value+'</td>';
//         var tale = doc.parentNode.parentNode;
//         tale.remove(doc);
//         var tale1 = num_add.parentNode.parentNode;
//         tale1.remove(num_add);

//         var name= document.getElementById("table_info");

        
//         var tr = document.createElement('tr');
//         tr.innerHTML = temp;
//         name.appendChild(tr);

//     }