export interface DataInterface {
    // id:number;
    Title:string;
    Content: string;
    Display: string;
    Checked:boolean;

}
