import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {CdkDropListGroup,CdkDropList,CdkDrag,CdkDragDrop} from '@angular/cdk/drag-drop'
import { AppComponent } from './app.component';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {Validator,FormsModule, ReactiveFormsModule} from "@angular/forms"
import {MatRadioModule} from '@angular/material/radio';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatCardModule} from '@angular/material/card';
import { ChildComponent } from "./child/child.component";
import { HttpClient,HttpClientModule } from '@angular/common/http';

@NgModule({
    declarations: [
        AppComponent
    ],
    providers: [],
    bootstrap: [AppComponent],
    imports: [
        MatCheckboxModule, MatCardModule, MatRadioModule, FormsModule, ReactiveFormsModule, MatButtonModule, MatIconModule, MatInputModule, BrowserModule, CdkDropListGroup, CdkDropList, CdkDrag, MatFormFieldModule, BrowserAnimationsModule,
        ChildComponent,HttpClientModule
    ]
})
export class AppModule { }
