export const data = [
    {
      id: 1,
      name: 'Samaria',
      content_body: 'asdd',
      disp: "block",

    },
    {
      id: 2,
      name: 'Gauthier',
      content_body: 'asdd',
      disp: 'block',

    },
    
  ];
  
  
  export const data2 = [
    {
      id: 1,
      name: 'inam',
      disp: true,

    },
    {
      id: 2,
      name: 'aqr',
      disp: true,

    },
  ];