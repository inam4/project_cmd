import { Component,OnInit } from '@angular/core';
import { data, data2 } from './data.service';
import { DataInterface } from './data-interface';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import {FormGroup,FormBuilder, Validators} from "@angular/forms"


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{

  users: DataInterface[] = data;
  users2: DataInterface[] = [];
  
  drop1(event: CdkDragDrop<DataInterface[]>): void {
    console.log(event.item.data);

    if (event.previousContainer !== event.container) {
    }
    // moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    transferArrayItem(
      event.previousContainer.data, 
      event.container.data,       
      event.previousIndex,        
      event.currentIndex            
    );
  }

  drop(event: CdkDragDrop<DataInterface[]>): void {
    transferArrayItem(
      event.previousContainer.data, // Source array
      event.container.data,         // Destination array
      event.previousIndex,          // Index in the source array
      event.currentIndex            // Index in the destination array
    );
  }

  AddButton(title:string,description:string): void {
    this.users.push({
      name: title,
      content_body: description,
      disp: "block"
    });
  }
  
  DeleteButton(i:number):void{
    this.users.splice(i,1);
  }
  

  DeleteButton_2(i:number):void{
    this.users2.splice(i,1);
  }
  
  Update_button(i:number):void{
    this.users[i].disp = 'none';
  }

  Update_button_2(i:number):void{
    this.users2[i].disp = 'none';
  }

  log(logout: any)
  {
    console.log(logout);
  }
  update_change(i:number,value:any,description:any)
  {   
      console.log(value);
      this.users[i].disp='block';
      this.users[i].name = value;
      this.users[i].content_body=description;
  }

  update_change_2(i:number,value:any,description:any)
  {   
      console.log(value);
      this.users2[i].disp='block';
      this.users2[i].name = value;
      this.users2[i].content_body=description;
  }
}




