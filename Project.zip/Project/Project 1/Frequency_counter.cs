using System;

public class String_Freqeuncy
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the sentence to count the frequency of each word:");
        string sentence = Console.ReadLine();
        string[] words = sentence.ToLower().Split(' ');
        int[] frequency = new int[words.Length];
        for(int i=0;i<words.Length;i++)
        {
            frequency[i] = 1;
            for(int j=i+1;j<words.Length;j++)
            {
                if(words[i]==words[j])
                {
                    frequency[i]++;

                }
            }
        }
        Console.WriteLine("The frequency of each word is: ");
        string[] word_done = new string[words.length];
        
        for(int i=0;i<words.Length;i++)
        {
            
            Console.WriteLine(words[i]+" "+frequency[i]);
        }
    }
}