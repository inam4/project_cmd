using System;

namespace Sentence_maker
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Enter 5 words to make random sentences:");   
      string[] words = new string[5]; 
      for(int i=0;i<5;i++)
      {
        words[i] = Console.ReadLine();
      }
      Console.WriteLine("How many sentences to create?");
      int n = Convert.ToInt32(Console.ReadLine());
      Random rand = new Random();
      for(int i=0;i<n;i++)
      {
        int a = rand.Next(0,5);
        int b = rand.Next(0,5);
        int c = rand.Next(0,5);
        int d = rand.Next(0,5);
        int e = rand.Next(0,5);
        Console.WriteLine(words[a]+" "+words[b]+" "+words[c]+" "+words[d]+" "+words[e]);
      }

    }
  }
}