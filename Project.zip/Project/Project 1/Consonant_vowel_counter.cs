using System;

namespace Consonant_vowel_counter
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Enter the sentence to check consonants and vowels:");
        string sentence = Console.ReadLine();
        string[] words = sentence.Split(' ');
        int[] consonant = new int[words.Length];
        int[] vowel = new int[words.Length];
        for(int i=0;i<words.Length;i++)
        {
            consonant[i] = 0;
            vowel[i] = 0;
            for(int j=0;j<words[i].Length;j++)
            {
                if(words[i][j]=='a'||words[i][j]=='e'||words[i][j]=='i'||words[i][j]=='o'||words[i][j]=='u'||words[i][j]=='A'||words[i][j]=='E'||words[i][j]=='I'||words[i][j]=='O'||words[i][j]=='U')
                {
                    vowel[i]++;
                }
                else
                {
                    consonant[i]++;
                }
            }
        }
        Console.WriteLine("Voewls and consonants count:");
        for(int i=0;i<words.Length;i++)
        {
            Console.WriteLine(words[i]+":"+vowel[i]+" vowels "+consonant[i]+"consonants");
        }
        
    }
  }
}