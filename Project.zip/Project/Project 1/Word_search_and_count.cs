using System;

namespace Word_search_and_count
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Enter the sentence to find the word from and to count how many times it appeared:");   
        string sentence = Console.ReadLine();
        string[] words = sentence.Split(' ');
        Console.WriteLine("Enter the word to search for:");
        string word = Console.ReadLine();
        int count = 0;
        for(int i=0;i<words.Length;i++)
        {
            if(words[i]==word)
            {
                count++;
            }
        }
        if (count==0)
        {
            Console.WriteLine("The word "+word+" did not appear in the sentence.");
        }
        else
        {
        Console.WriteLine("The word "+word+" appeared "+count+" times.");
        }
   
    }
  }
}