﻿using System;

public class String_Freqeuncy
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the sentence to count the frequency of each word:");
        string sentence = Console.ReadLine();
        Console.WriteLine(sentence[1]);
        string[] words = sentence.ToLower().Split(' ');
        string[] words_check = sentence.ToLower().Split(' ');
        int[] frequency = new int[words.Length];
      

        for (int i = 0; i < words.Length; i++)
        {
            frequency[i] = 1;
            for (int j = i + 1; j < words.Length; j++)
            {
                if (words[i] == words[j])
                {
                    frequency[i]++; //frequency[i]=frequency[i]+1;
                    words[j] = "0";
                }
            }
        }
        Console.WriteLine("Word Frequency:");


        for (int i = 0; i < words_check.Length; i++) //compares with the initial array of words
        {
            if (words[i] == words_check[i])
            {
                Console.WriteLine(words[i] + ": " + frequency[i]);

            }
        }
    }
}