﻿using System;

namespace Longest_shortest_word_finder
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the sentence to find the longest and shortest word:");
            string sentence = Console.ReadLine();
            string[] words = sentence.Split(' ');
            int[] length = new int[words.Length];
            for (int i = 0; i < words.Length; i++)
            {
                length[i] = words[i].Length;
            }
            int max = -1;
            int min = 999999;
            for (int i = 0; i < words.Length; i++)
            {
                if (length[i] > max)
                {
                    max = length[i];
                }
                if (length[i] < min)
                {
                    min = length[i];
                }
            }
            Console.WriteLine("The longest word is: ");
            for (int i = 0; i < words.Length; i++)
            {
                if (length[i] == max)
                {
                    Console.WriteLine(words[i]);
                }
            }
            Console.WriteLine("The shortest word is: ");
            for (int i = 0; i < words.Length; i++)
            {
                if (length[i] == min)
                {
                    Console.WriteLine(words[i]);
                }
            }
        }
    }
}