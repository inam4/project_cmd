﻿using System;

namespace Palindrome_Detector
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the sentence to check if it contains a palindrome:");
            string sentence = Console.ReadLine();
            string[] words = sentence.Split(' ');
            int[] length = new int[words.Length];
            for (int i = 0; i < words.Length; i++)
            {
                for (int j = 0; j < words[i].Length; j++)
                {
                    if (words[i][j] == words[i][words[i].Length - 1 - j])
                    {
                        Console.WriteLine("The word " + words[i] + " is a palindrome.");

                    }
                }
            }

        }
    }