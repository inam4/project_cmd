const button1 = document.getElementById("add_value");
button1.addEventListener("click",function()
{   
   
    var element =  document.getElementById('add_e');
    if (typeof(element) != 'undefined' && element != null)
    {
       
        var num_add = document.getElementById("add_num");
      
        var doc = document.getElementById("add_name").parentNode;
        const tale = doc.parentNode;
        tale.removeChild(doc);
        var doc = document.getElementById("add_num").parentNode;
        const tale1 = doc.parentNode;
        tale1.removeChild(doc);

        var name= document.getElementById("table_info");

        var temp = '<td>'+ name_add.value + '</td><td>'+num_add.value+'</td>';
        var tr = document.createElement('tr');
        tr.innerHTML = temp;
        name.appendChild(tr);

    }else
    {
      
    }
  
    var name= document.getElementById("table_info");

    var temp = '<td>'+ '<input type="text" id="add_e" name="add_name">' + '</td><td>'+'<input type="text" id="add_num" name="add_num">'+'</td>';
    var tr = document.createElement('tr');
    tr.innerHTML = temp;
    name.appendChild(tr);

});
