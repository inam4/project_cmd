const myImage = document.getElementById('myImage');
const changeButton = document.getElementById('changeButton');

let isOriginalImage = true;

function changeImage() {
	if (isOriginalImage) {
		myImage.src = 'photo1.png'; 
		changeButton.textContent = 'Click Here';
		isOriginalImage = false;
	} else {
		myImage.src = 'photo2.png';
		changeButton.textContent = 'Click Here';
		isOriginalImage = true;
	}
}

changeButton.addEventListener('click', changeImage);