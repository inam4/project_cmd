$(document).ready(function() {
    $.ajax({
        url: "http://localhost:3013/GetPosts",
        type: "GET",
        datatype: "json",
        success: function(data) {
            $("#is").append(data.length);
        },
        error: function(error) {}
    });
});