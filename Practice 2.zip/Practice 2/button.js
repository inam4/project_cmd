
const button = document.getElementById("button1");
button.addEventListener("click",function()
{
    let name1 = document.getElementById("name").value;
    if(name1.length==0)
    {
        alert("Name field empty. Please fill in the name field.");
        
    }
    let email1 = document.getElementById("email").value;
    if(email1.length==0)
    {
        alert("Email field empty. Please fill in the email field.");
        
    }
 
});