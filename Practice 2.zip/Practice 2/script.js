const styleSheet = document.styleSheets[0];
var rules = styleSheet.cssRules;


let x = -1;

for(let i =0;i<rules.length;i++)
    {
        const rule = '.topnav a:hover';
        if(rule == styleSheet.cssRules[i].selectorText)
        {
            x=i;
        }
    }

if(x!=-1)
{
styleSheet.deleteRule(x);
    
}
styleSheet.insertRule('.topnav a:hover { background-color: #ddd; color: orange; }', x);


