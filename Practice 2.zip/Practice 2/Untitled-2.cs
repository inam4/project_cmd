 string S = "^vv<v";
            int count_1 = 0;
            int count_2 = 0;

            int count_3 = 0;
            int count_4 = 0;
            int[] S_ = {0,0,0,0 };
            
            for (int i=0;i<S.Length;i++)
            {
                if(S[i]==Convert.ToChar("^"))
                {
                    count_1 = count_1 + 1;
                    S_[0] = count_1;
                }
                else if (S[i] == Convert.ToChar("v"))
                {
                    count_2 = count_2 + 1;
                    S_[1] = count_2;

                }
                else if (S[i] == Convert.ToChar("<"))
                {
                    count_3 = count_3 + 1;
                    S_[2] = count_3;

                }
                else if (S[i] == Convert.ToChar(">"))
                {
                    count_4 = count_4 + 1;
                    S_[3] = count_4;

                }
            }
            int max_x = 0;
            foreach(var l in S_)
            {
                if(l>max_x)
                {
                    max_x = l;
                }
            }
            Console.WriteLine(max_x);




            int pos_a = 0;
            int pos_b = 0;
            bool is_a = true;
            bool is_b = false;
            for (int i = 0; i < S.Length; i++)
            {
                if (S[i] == Convert.ToChar('a'))
                {
                    pos_a = i;
                    is_a = true;
                }
                else if (S[i] == Convert.ToChar('b'))
                {
                    pos_b = i;
                    is_b = true;
                }
            }
            if ((pos_a < pos_b) && is_a == true && is_b == true)
            {
                Console.WriteLine("True");
            }
            else if ((pos_a > pos_b) && is_a==true && is_b==true)
            {
                Console.WriteLine("false");
            }
            else if (is_a==true || is_b==true)
            {
                Console.WriteLine("true");
            }
            else if (is_a == true)
            {
                Console.WriteLine("true");
            }
            else
            {
                Console.WriteLine("False");
            }