﻿using System;

namespace Question_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input number to know if its a perfect square : ");
            int num = Convert.ToInt32(Console.ReadLine());
            int sum = 0;
            for(int i=1;i<num;i++)
            {
               
                if(num%i==0) //if remainder is 0, the it means number is a factor and therefore, it is added to sum.
                {
                    sum = sum + i;
                }
            }
            if (sum == num)
            {
                Console.WriteLine("The number " + num + " is a perfect number");
            }
            else
            {
                Console.WriteLine("The number " + num + " is not a perfect number");
            }
        }
    }
}
