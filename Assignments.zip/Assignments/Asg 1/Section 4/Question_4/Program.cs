﻿using System;

namespace Question_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input the height of the triangle : ");

            int height = Convert.ToInt32(Console.ReadLine());
            int count = 0;
            for (int i = 0; i < height; i++)
            {
                count = count + 1; 

                for (int x = 0; x < count; x++)
                {
                    Console.Write(x+1);
                }
                Console.WriteLine();

            }

        }
    }
}
