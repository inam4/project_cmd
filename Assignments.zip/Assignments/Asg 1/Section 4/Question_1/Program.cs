﻿using System;

namespace Question_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter string to get its reverse");
            string str = Console.ReadLine();

            for (int i = 0; i < str.Length; i++)
            {
                Console.Write("Reverse string is "+str[str.Length - 1 - i]);
            }
        }
    }
}
