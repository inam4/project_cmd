﻿using System;

namespace Question_5
{
    class Program
    {
        static void Main(string[] args)
        {
            string str_1 = "ABCDRH";
            string str_2 = "AEDFHR";
            string str_3 = "";
            string str_4 = "";
            string str_5 = "";
            for (int i=0; i<str_1.Length; i++)
            {
                for(int x=0;x<str_2.Length;x++)
                {
                    if (str_1[i] == str_2[x])
                    {
                        str_3 = str_3 + str_1[i];
                    }
                    if (str_1[x] == str_2[i])
                    {
                        str_4 = str_4 + str_2[i];
                    }
                }
             
            }
        
            for (int i=0; i<str_3.Length;i++)
            {
                if(str_3[i]==str_4[i])
                {
                    str_5 = str_5 + str_3[i];
                }
            }
            Console.WriteLine(str_5);

        }
    }
}
