﻿using System;

namespace Question_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write the number to find from the array");
            int num_find = Convert.ToInt32(Console.ReadLine());
            int[] num = { 24, 32, 45, 64, 27 };

            bool Is_num = false;
            foreach(int number in num)
            {
                if (num_find == number) //Compares each number from the array "num" and changes the boolean value "Is_num" to true if number is found.
                {
                    Is_num = true;
                }
            }
            if(Is_num==true)
            {
                Console.WriteLine("Number Found");
            }
            else
            {
                Console.WriteLine("Number not found");
            }
        }
    }
}
