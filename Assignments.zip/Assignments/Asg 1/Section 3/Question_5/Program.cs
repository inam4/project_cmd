﻿using System;

namespace Question_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input the height of the triangle : ");

            int height = Convert.ToInt32(Console.ReadLine());
            int count = 1;
            for (int i = 0; i < height; i++)
            {
               
                for (int y = 0; y < height - i - 1; y++)
                {
                    Console.Write(" ");
                }
                for (int x = 0; x < count; x++)
                {
                 
                    Console.Write("*");
                }
                Console.WriteLine();
                count = count + 2; //Count is incremented after each run to increase the number of *. The number of "*" are odd values.
            }

        }
    }
}
