﻿using System;

namespace Question_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter string to check if its a palindrome");
            string str =  Console.ReadLine();
            bool Is_string = true; //string is assumed to be a palindrome
            
            for(int i=0; i<str.Length;i++)
            {
                if (str[i] != str[str.Length -1- i])  //compares the start and corresponding end values of the string
                {
                    Is_string = false;
                }


            }
            if (Is_string == true)
            {
                Console.WriteLine("It's a palindrome");
            }
            else
            {
                Console.WriteLine("It's not a palindrome :(");
            }

        }
    }
}
