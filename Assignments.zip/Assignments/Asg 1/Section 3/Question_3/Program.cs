﻿using System;

namespace Question_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int? temp_value = null;
            int[] unsorted_array = { 4, 6, 2, 8, 6, 1 };
            for(int i=0; i<unsorted_array.Length ;i++)
            {
                for(int p =0; p<unsorted_array.Length ;p++)
                {
                    if(p!=i)
                    {
                        if(unsorted_array[i]>unsorted_array[p]) //compares if the next value except the number itself is larger or smaller. If larger then the largest number is assigned to upper index and smaller is assigned a lower index.
                        {
                            temp_value = unsorted_array[i];
                            unsorted_array[i] = unsorted_array[p];
                            unsorted_array[p] = (int)temp_value;

                        }
                    }
                }
            }
            Console.WriteLine("The largest number is " + unsorted_array[0]);
            Console.WriteLine("The smallest number is " + unsorted_array[unsorted_array.Length-1]);

        }
    }
}
