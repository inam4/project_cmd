﻿using System;

namespace Question_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number : ");
            int num = Convert.ToInt32(Console.ReadLine()); //Value entered by user is converted to integer.
     
            int total = 0;
            for (int i = 1; i <=num; i++) //Loops run from 1 till num and "i" is added to total.
            {
                total = total + i;
            }

            Console.Write("The sum of number from 1 to " + num);
            Console.WriteLine(" is " + total); //Prints the total number

        }
    }
}
