﻿using System;

namespace Question_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int num_1 = 0;
            int num_2 = 1;
            Console.Write("Till how many terms is fibonacci number needed ");
            int num =  Convert.ToInt16(Console.ReadLine());
            if (num==1)
            {
                Console.WriteLine("The 1 term of series is 0");
            }
            else
            {
                Console.WriteLine("The 1 term of series is 0");
                for (int i = 2; i <= num;i++)
                {
                    //The formula of fibonnaci is Fn-1+Fn-2 where n is the ith term.
                    int fib_term = num_2 + num_1;
                    Console.WriteLine("The " + i + " term of series is " + fib_term); 
                    //The 1st number is assigned the previous number and 2nd number is assigned the present fibonnaci number
                    num_1 = num_2;
                    num_2 = fib_term;
                }
            }
            
        }
    }
}
