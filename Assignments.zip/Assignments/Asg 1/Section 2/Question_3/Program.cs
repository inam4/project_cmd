﻿using System;

namespace Question_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input the number : ");
            int num = Convert.ToInt32(Console.ReadLine());
            for (int i= 2; i <= num; i++)
            {
                PrimeNumberCheck(i); //Prime number check function for the number.
            }
        }

        static void PrimeNumberCheck(int num)
        {
            bool isPrime = true; //Number is assumed to be a prime number.
            int end_num = num / 2; //Half is taken for entered num because its multiples lies below the half number.
            for(int i=2;i<=end_num; i++) //Loop is run from 2 to the end number. 1 is omitted because its not a prime number.
            {
                if (num%i==0)
                {
                    isPrime = false; //If factor is found, then it is flagged as false(Not a prime number).
                }
            }
            if (isPrime == true) 
            {
                Console.WriteLine(num + " is a prime number"); //Number is flagged as prime at the end of loop.
            }
        }
    }
}
