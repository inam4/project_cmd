﻿using System;

namespace Question_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write the number to compute the factorial");
            int num = Convert.ToInt32(Console.ReadLine()); 
            int factorial_num = 1;
            for(int i=1;i<=num; i++)
            {
                factorial_num = factorial_num * i; //number(i) is multiplied by preceding number stored in the factorial_num and is then stored back in factorial_num
            }

            Console.WriteLine("The factorial of the number " + num + " is " + factorial_num);

        }
    }
}
