﻿using System;

namespace Question_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Write the number to create the multiplication table: ");
            int num = Convert.ToInt32(Console.ReadLine());

            for (int i=1;i<=12;i++)
            {
                Console.WriteLine(num + " x " + i + " = " + (num * i)); //Multiplies the number with the integer(i) that iterates from 1 to 12.
            }
        }

    }
}
