﻿using System;

namespace Question_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number to square: ");
            int num = Convert.ToInt32(Console.ReadLine()); // Converts string to int that is taken as input by the user
            squared_num(num);
        }

        static void squared_num(int num1)
        {
            Console.WriteLine("Your squared number is " + (num1 * num1)); //Multiply the number by itself and outputs a squared number.
        }
    }
}