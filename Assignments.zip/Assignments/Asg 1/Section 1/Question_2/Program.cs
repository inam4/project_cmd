﻿using System;

namespace Question_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your username");
            string username = Console.ReadLine(); // User is asked for their name
            Console.WriteLine("Hello, " + username); //Username is printed on console

        }
    }
}
