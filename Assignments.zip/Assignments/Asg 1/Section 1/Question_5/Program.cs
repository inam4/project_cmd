﻿using System;

namespace Question_5
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("The following are the even numbers");
            for (int i = 0; i <= 100; i++) //Loops runs 101 tumes
            {
                if (i%2==0) //Checks if the number is divisble by 2 and returns remainder 0
                {
                    Console.WriteLine(i); //Prints the even number
                }
            }
        }
    }
}