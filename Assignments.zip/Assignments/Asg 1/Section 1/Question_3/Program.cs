﻿using System;

namespace Question_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter integer(1) : ");
            int num1 = Convert.ToInt32(Console.ReadLine()); //Ask for an integer and stores its values to variable nameed "num1"

            Console.Write("Enter integer(2) : ");
            int num2 = Convert.ToInt32(Console.ReadLine());  //Ask for an integer and stores its values to variable nameed "num2"

            Console.WriteLine("The sum of two integer is " + (num1 + num2));
        }
    }
}
