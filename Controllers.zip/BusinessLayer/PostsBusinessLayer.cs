﻿using System;
using System.Collections.Generic;
using System.Data;
using Web_API.Data_Layer;
using Web_API.Models;

namespace Web_API.BusinessLayer
{
    public class PostsBL
    {

        public PostsDL dataLayer = new PostsDL();
        public List<Posts> GetPosts()
        {
            try
            {
                DataTable table = new DataTable();
                List<Posts> listsPosts = new List<Posts>();
                table = dataLayer.GetPosts();

                if (table != null && table.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in table.Rows)
                    {
                        Posts post = new Posts();
                        post.PostsId = Convert.ToInt32(dataRow["PostId"]);
                        post.Title = dataRow["Title"].ToString();
                        post.Content = dataRow["Content"].ToString();

                        listsPosts.Add(post);
                    }
                }
                return listsPosts;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfStudents due to "
                   + exception.Message, exception.InnerException);
            }
        }

        //public string InsertStudent(Students student)
        //{
        //    try
        //    {
        //        string response = dataLayer.InsertStudentInDB(student);
        //        return response;
        //    }
        //    catch (Exception exception)
        //    {
        //        throw new Exception("An exception of type " + exception.GetType().ToString()
        //           + " is encountered in InsertStudent due to "
        //           + exception.Message, exception.InnerException);
        //    }
        //}
    }
}