﻿namespace Web_API.Models
{
    public class Students
    {
        public int studentId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string studentAddress { get; set; }
        public string studentAge { get; set; }
        public string phoneNumber { get; set; }

    }
}