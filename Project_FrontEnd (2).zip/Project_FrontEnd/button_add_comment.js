const button1 = document.getElementById("add_value");
button1.addEventListener("click",function()
{   
    alert("eS");
    var element =  document.getElementById('add_name');
    if (typeof(element) != 'undefined' && element != null)
    {
       
      
        var doc = document.getElementById("add_name");
        var num_add = document.getElementById("add_num");
        var temp = '<td>'+ doc.value + '</td><td>'+num_add.value+'</td>';
        var tale = doc.parentNode.parentNode;
        tale.remove(doc);
        var tale1 = num_add.parentNode.parentNode;
        tale1.remove(num_add);

        var name= document.getElementById("table_info");

        
        var tr = document.createElement('tr');
        tr.innerHTML = temp;
        name.appendChild(tr);

    }else
    {
        var name= document.getElementById("table_info");

        var temp = '<td>'+ '<input type="text" id="add_name" name="add_name">' + '</td><td>'+'<input type="text" id="add_num" name="add_num">'+'</td>';
        var tr = document.createElement('tr');
        tr.innerHTML = temp;
        name.appendChild(tr);
      
    }
  
    
});

