IF EXISTS (SELECT 1 FROM sys.procedures WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[GetComments]'))
    DROP PROCEDURE GetComments;
GO

CREATE PROCEDURE GetComments
AS
BEGIN
    SELECT CommentsId,PostId, UserId, Content FROM [Comments];
END


