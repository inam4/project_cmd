IF EXISTS (SELECT 1 FROM sys.procedures WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[GetComments_v1]'))
    DROP PROCEDURE GetComments_v1;
GO

CREATE PROCEDURE GetComments_v1
AS
BEGIN
    SELECT
        u.Email,
        c.CommentsId,
        u.Name,
        c.Content,
        c.Postid,
        c.UserId
    FROM
        [Users] u
    INNER JOIN
        [dbo].[Comments] c ON u.UserId = c.UserId
    
END

