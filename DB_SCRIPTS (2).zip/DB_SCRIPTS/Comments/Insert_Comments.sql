IF EXISTS (SELECT 1 FROM sys.procedures WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[InsertComment]'))
    DROP PROCEDURE InsertComment;
GO

CREATE PROCEDURE InsertComment
    @PostId int,
	@UserId int,
	@Content VARCHAR(100),
	@PKID int = 0 output
AS
BEGIN
    INSERT INTO [dbo].[Comments](PostId,UserId, Content)
	VALUES (@PostId,@UserId,@Content)

	SET @PKID = SCOPE_IDENTITY()

	SELECT @PKID as PKID
END

//SELECT * FROM [dbo].[Comments]
