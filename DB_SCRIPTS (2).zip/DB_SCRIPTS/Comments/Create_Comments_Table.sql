IF OBJECT_ID(N'[dbo].[Comments]', N'U') IS NOT NULL
    DROP TABLE [dbo].[Comments]

CREATE TABLE [dbo].[Comments] (
    CommentsId int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	PostId int,
    UserId int,
    Content varchar(30) NOT NULL

)