IF EXISTS (SELECT 1 FROM sys.procedures WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[GetPosts]'))
    DROP PROCEDURE GetPosts;
GO

CREATE PROCEDURE GetPosts
AS
BEGIN
    SELECT PostId, Title, Content FROM [Posts];
END