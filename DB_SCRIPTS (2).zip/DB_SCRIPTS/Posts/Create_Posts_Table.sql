IF EXISTS (SELECT 1 FROM sys.tables WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[Posts]'))
DROP TABLE [Posts]
BEGIN
	CREATE TABLE [Posts] 
	(
		PostId int PRIMARY KEY IDENTITY(1,1) NOT NULL,
		UserId int,
		Title varchar(30) NOT NULL,
		Content varchar (30) NOT NULL,
		)
END