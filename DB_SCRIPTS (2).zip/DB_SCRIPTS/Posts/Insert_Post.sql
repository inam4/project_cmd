
IF EXISTS (SELECT 1 FROM sys.procedures WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[InsertPosts]'))
    DROP PROCEDURE InsertPosts;
GO

CREATE PROCEDURE InsertPosts
	@UserId int,
	@Title VARCHAR(100),
	@Content VARCHAR(100),
	@PKID int = 0 output
AS
BEGIN
    INSERT INTO [dbo].[Posts](Title,UserId, Content)
	VALUES (@Title,@UserId,@Content)

	SET @PKID = SCOPE_IDENTITY()

	SELECT @PKID as PKID
END


