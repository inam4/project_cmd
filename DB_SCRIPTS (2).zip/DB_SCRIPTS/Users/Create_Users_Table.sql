IF EXISTS (SELECT 1 FROM sys.tables WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[4099_Student]'))
DROP TABLE [Users]
BEGIN
	CREATE TABLE [Users] (
		UserId int PRIMARY KEY IDENTITY(1,1) NOT NULL,
		Name varchar(30) NOT NULL,
		Email varchar (30) NOT NULL,
		Password varchar (100) NOT NULL,

END