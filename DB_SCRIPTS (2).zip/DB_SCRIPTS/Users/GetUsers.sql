IF EXISTS (SELECT 1 FROM sys.procedures WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[GetUsers]'))
    DROP PROCEDURE GetUsers;
GO

CREATE PROCEDURE GetUsers
AS
BEGIN
    SELECT UserId, Name, Email,Password FROM [Users];
END