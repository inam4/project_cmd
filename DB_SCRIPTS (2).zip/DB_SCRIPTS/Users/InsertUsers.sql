IF EXISTS (SELECT 1 FROM sys.procedures WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[InsertUsers]'))
    DROP PROCEDURE InsertUsers;
GO

CREATE PROCEDURE InsertUsers
	@Name VARCHAR(30),
	@Email VARCHAR(30),
	@Password VARCHAR(30),
	@PKID int = 0 output
AS
BEGIN
    INSERT INTO [dbo].[Users](Name,Email, Password)
	VALUES (@Name,@Email,@Password)

	SET @PKID = SCOPE_IDENTITY()

	SELECT @PKID as PKID
END

