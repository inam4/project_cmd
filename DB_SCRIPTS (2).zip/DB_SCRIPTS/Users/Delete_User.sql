CREATE PROCEDURE DeleteUserData
    @UserId Int
AS
BEGIN
    -- Delete from Comments table
    DELETE FROM [dbo].[Comments]
    WHERE UserId = @UserId;

    -- Delete from Posts table
    DELETE FROM [dbo].[Posts]
    WHERE UserId = @UserId;

    -- Delete from Users table
    DELETE FROM [dbo].[Users]
    WHERE UserId = @UserId;
END