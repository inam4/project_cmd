﻿using System;
using System.Collections.Generic;
using System.Data;
using Web_API.Data_Layer;
using Web_API.Models;
namespace Web_API.BusinessLayer
{
    public class UsersBusinessLayer
    {
        public UsersDL dataLayer = new UsersDL();
        public List<Users> GetUsers()
        {
            try
            {
                DataTable table = new DataTable();
                List<Users> listsUsers = new List<Users>();
                table = dataLayer.GetUsers();

                if (table != null && table.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in table.Rows)
                    {
                        Users post = new Users();
                        post.Name = dataRow["Name"].ToString();
                        post.Email = dataRow["Email"].ToString();
                        post.Password = dataRow["Password"].ToString();
                        post.UserId = Convert.ToInt32(dataRow["UserId"]);
                        
                        listsUsers.Add(post);
                    }
                }
                return listsUsers;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfStudents due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public string InsertUsers(Users post)
        {
            try
            {
                string response = dataLayer.InsertUsers(post);
                return response;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in InsertStudent due to "
                   + exception.Message, exception.InnerException);
            }
        }


        public string DeleteUsers(int post1)
        {
            try
            {
                string response = dataLayer.DeleteUsers(post1);
                return response;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in InsertStudent due to "
                   + exception.Message, exception.InnerException);
            }
        }
    }
}