﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API.BusinessLayer;
using Web_API.Models;


namespace Web_API.Controllers
{
    public class UsersController :ApiController
    {
        public UsersBusinessLayer Users_dataLayer = new UsersBusinessLayer();

        // GET api/<controller>
        [HttpGet]
        [Route("GetUsers")]
        public List<Users> GetUsers()
        {
            try
            {
                List<Users> Users = new List<Users>();
                Users = Users_dataLayer.GetUsers();
                return Users;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfStudents due to "
                   + exception.Message, exception.InnerException);
            }
        }



        [HttpDelete]
        [Route("DeleteUsers/{userId:int}")]
        public string DeleteUsers(int userId)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    string resposne = Users_dataLayer.DeleteUsers(userId);
                    if (!string.IsNullOrEmpty(resposne))
                    {
                        return "Student Added Successfully!";
                    }
                    else
                    {
                        return "Student Not Added Successfully!";
                    }
                }
                else
                {
                    return "Model Is Not Valid";
                }
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in InsertStudent due to "
                   + exception.Message, exception.InnerException);
            }
        }



        [HttpPost]
        [Route("InsertUsers")]
        public string InsertUsers(Users comment)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    string resposne = Users_dataLayer.InsertUsers(comment);
                    if (!string.IsNullOrEmpty(resposne))
                    {
                        return "Student Added Successfully!";
                    }
                    else
                    {
                        return "Student Not Added Successfully!";
                    }
                }
                else
                {
                    return "Model Is Not Valid";
                }
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in InsertStudent due to "
                   + exception.Message, exception.InnerException);
            }
        }





        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}
