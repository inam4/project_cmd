﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagement
{
    public class Bank
    {
        public List<BankAccount> Customer_Account;
        public Bank()
        {
            Customer_Account = new List<BankAccount>();
        }

        public void AddAccount(BankAccount bank_account)
        {
            Customer_Account.Add(bank_account);
            bank_account.DisplayAccountInfo();
        }

        public void DepositToAccount(BankAccount bank_account, double Amount_Add)
        {
            bank_account.Deposit(Amount_Add);

        }

        public void WithdrawFromAccount(BankAccount bank_account, double Amount_DEL)
        {

            bank_account.Withdraw(Amount_DEL);

        }
        public void CheckAccount(BankAccount bank_account)
        {

            bank_account.DisplayAccountInfo();

        }
    }
}
