﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagement
{
    public abstract class BankAccount : IBankAccount
    {
        private string name;
        protected int accountnumber;
        protected double balance;
        public string Account_type;
        public List<double> Deposit_List;
        public List<double> Withdraw_List;

        Dictionary<string, List<double>> t_history;

        public string Name
        {
            get { return name; }
            set { name = value; }

        }

        public int AccountNumber
        {
            get { return accountnumber; }
            set { accountnumber = value; }
        }

        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }
        public BankAccount(string name, int acc_number, double balance, string account_type)
        {
            //Initialising so that they can be used within classes inherited.
            Name = name;
            AccountNumber = acc_number;
            Balance = balance;
            Account_type = account_type;
            Deposit_List = new List<double>();
            t_history = new Dictionary<string, List<double>>();

        }

        public virtual void Deposit(double Amount_Add)
        {
            Balance = Balance + Amount_Add;
            Console.WriteLine($"{Name}'s Account with ID {AccountNumber} credited with amount {Amount_Add} ");
            Console.WriteLine($"New Balance is PKR{Balance}");
            Deposit_List.Add(Amount_Add);
            t_history.Add("Deposit", Deposit_List);
           
        }

        public virtual void Withdraw(double DEL)
        {
            Balance = Balance - DEL;
            Console.WriteLine($"{Name}'s Account with ID {AccountNumber} decredited with amount {DEL} ");
            Console.WriteLine($"New Balance is PKR{Balance}");
        }

        public abstract void DisplayAccountInfo();

        public virtual double CalculateInterest(double interest)
        {
            return interest;
        }


    }

}
