﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagement
{
    public class CheckingAcccount : BankAccount, ITransaction
    {
        public CheckingAcccount(string name, int acc_number, double balance) : base(name, acc_number, balance, "Checking Account")
        {

        }


        public override void Withdraw(double DEL)
        {
            if (Balance == DEL)
            {
                Console.WriteLine("Amount not added. Current balance is equal to Withdrawal");
            }
            else
            {
                Balance = Balance - DEL;
                Console.WriteLine($"{Name}'s Account with ID {AccountNumber} decredited with amount {DEL} ");
                Console.WriteLine($"New Balance is PKR{Balance}");
            }
        }
        public override void DisplayAccountInfo()
        {
            Console.WriteLine($"Account Number: {AccountNumber}");
            Console.WriteLine($"Bank Account Type: {Account_type}");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Balance: {Balance}");
        }
        public void ExecuteTransaction(double amount, string transaction_type)
        {
            if (transaction_type == "Deposit")
            {
                Deposit(amount);
                PrintTransaction(amount, transaction_type);
            }
            else if (transaction_type == "Withdraw")
            {
                Withdraw(amount);
                PrintTransaction(amount, transaction_type);
            }
        }

        public void PrintTransaction(double amount, string transaction_type)
        {

            Console.WriteLine($"Account Number: {AccountNumber}");
            Console.WriteLine($"Bank Account Type: {Account_type}");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Balance  {transaction_type}ed: {amount}");
            Console.WriteLine($"New Balance: {Balance}");
        }

    }
}
