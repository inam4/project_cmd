﻿using System;
using System.Collections.Generic;

//interface ITransaction
//{
//    void ExecuteTransaction(double amount,string transaction_type);
//    void PrintTransaction(double amount,string transaction_type);
//}
//interface IBankAccount  //the class that inherits from interface class must have methods mentioned.
//{
//    void Deposit(double amount);
//    void Withdraw(double amount);

//}
//public abstract class BankAccount : IBankAccount
//{
//    private string name;
//    protected int accountnumber;
//    protected double balance;
//    public string Account_type;

//    public string Name
//    {
//        get { return name; }
//        set { name = value; }
//    }

//    public int AccountNumber
//    {
//        get { return accountnumber; }
//        set {accountnumber = value; }
//    }

//    public double Balance
//    {
//        get { return balance; }
//        set { balance = value; }
//    }
//    public BankAccount(string name,int acc_number,double balance,string account_type)
//    {
//        //Initialising so that they can be used within classes inherited.
//        Name = name;
//        AccountNumber = acc_number;
//        Balance = balance;
//        Account_type = account_type;
//    }

//    public virtual void Deposit(double Amount_Add)
//    {
//        Balance = Balance + Amount_Add;
//        Console.WriteLine($"{Name}'s Account with ID {AccountNumber} credited with amount {Amount_Add} ");
//        Console.WriteLine($"New Balance is PKR{Balance}");
//    }
    
//    public virtual void Withdraw(double DEL)
//    {
//        Balance = Balance - DEL;
//        Console.WriteLine($"{Name}'s Account with ID {AccountNumber} decredited with amount {DEL} ");
//        Console.WriteLine($"New Balance is PKR{Balance}");
//    }

//    public abstract void DisplayAccountInfo();

//    public virtual double CalculateInterest(double interest)
//    {
//        return interest;
//    }


//}

//public class SavingsAcccount : BankAccount,ITransaction
//{
//    public double InterestRate;

//    public SavingsAcccount(string name, int acc_number, double balance,double interest) : base(name, acc_number, balance, "Savings Account")
//    {
//        InterestRate = interest;
//    }
//    public override double CalculateInterest(double InterestRate)
//    {
//        Balance = ((InterestRate / 100) * (Balance)) + Balance;
//        return Balance;
//    }
//    public override void Deposit(double Amount_Add)
//    {
       
//        Balance = Balance + Amount_Add;
//        Balance =CalculateInterest(InterestRate);
//        Console.WriteLine($"{Name}'s Account with ID {AccountNumber} credited with amount {Amount_Add} and Interest Rate {InterestRate}%");
//        Console.WriteLine($"New Balance is PKR{Balance}");
//    }
//    public override void DisplayAccountInfo()
//    {
//        Console.WriteLine($"Account Number: {AccountNumber}");
//        Console.WriteLine($"Bank Account Type: {Account_type}");
//        Console.WriteLine($"Name: {Name}");
//        Console.WriteLine($"Balance: {Balance}");
//    }

//    public void ExecuteTransaction(double amount,string transaction_type)
//    {
//        if(transaction_type =="Deposit")
//        {
//            Deposit(amount);
//            PrintTransaction(amount,transaction_type);
//        }
//        else if (transaction_type == "Withdraw")
//        {
//            Withdraw(amount);
//            PrintTransaction(amount,transaction_type);
//        }
//    }

//    public void PrintTransaction(double amount,string transaction_type)
//    {

//        Console.WriteLine($"Account Number: {AccountNumber}");
//        Console.WriteLine($"Bank Account Type: {Account_type}");
//        Console.WriteLine($"Name: {Name}");
//        Console.WriteLine($"Balance  {transaction_type}ed: {amount}");
//        Console.WriteLine($"New Balance: {Balance}");
//    }
//}

//public class LoanAccount : BankAccount,ITransaction
//{
//    public double InterestRate;
//    public int Time_in_years;
//    public int Number_of_times_interest_compounded;
//    public double Loan_balance; 

//    public LoanAccount(string name, int acc_number, double balance,int n_of_times_interest_compounded,int time_in_years,double interest_rate) : base(name, acc_number, balance, "Loan Account")
//    {
//        InterestRate = interest_rate;
//        Number_of_times_interest_compounded = n_of_times_interest_compounded;
//        Time_in_years = time_in_years;
//        Loan_balance = CalculateInterest(InterestRate);
//        Balance = Loan_balance;
        
//    }

//    public override double CalculateInterest(double interest)
//    {
//        double amount = Balance * Math.Pow((1 + ((InterestRate / 100) / Number_of_times_interest_compounded)),(Number_of_times_interest_compounded*Time_in_years));
//        return amount;
//    }

//    public override void Withdraw(double DEL)
//    {
//        if (Balance == DEL)
//        {
//            Console.WriteLine("Amount not added. Current balance is equal to Withdrawal");
//        }
//        else
//        {
//            Balance = Balance - DEL;
//            Console.WriteLine($"{Name}'s Account with ID {AccountNumber} decredited with amount {DEL} ");
//            Console.WriteLine($"New Balance is PKR{Balance}");
//        }
//    }
//    public override void DisplayAccountInfo()
//    {
//        Console.WriteLine($"Account Number: {AccountNumber}");
//        Console.WriteLine($"Bank Account Type: {Account_type}");
//        Console.WriteLine($"Name: {Name}");
//        Console.WriteLine($"Balance: {Balance}");
//    }
//    public void ExecuteTransaction(double amount, string transaction_type)
//    {
//        if (transaction_type == "Deposit")
//        {
//            Deposit(amount);
//            PrintTransaction(amount, transaction_type);
//        }
//        else if (transaction_type == "Withdraw")
//        {
//            Withdraw(amount);
//            PrintTransaction(amount, transaction_type);
//        }
//    }

//    public void PrintTransaction(double amount, string transaction_type)
//    {

//        Console.WriteLine($"Account Number: {AccountNumber}");
//        Console.WriteLine($"Bank Account Type: {Account_type}");
//        Console.WriteLine($"Name: {Name}");
//        Console.WriteLine($"Balance  {transaction_type}ed: {amount}");
//        Console.WriteLine($"New Balance: {Balance}");
//    }

//}
//public class CheckingAcccount : BankAccount,ITransaction
//{
//    public CheckingAcccount(string name, int acc_number, double balance) : base(name, acc_number, balance, "Checking Account")
//    {

//    }
   

//    public override void Withdraw(double DEL)
//    {
//        if (Balance == DEL)
//        {
//            Console.WriteLine("Amount not added. Current balance is equal to Withdrawal");
//        }
//        else
//        {
//            Balance = Balance - DEL;
//            Console.WriteLine($"{Name}'s Account with ID {AccountNumber} decredited with amount {DEL} ");
//            Console.WriteLine($"New Balance is PKR{Balance}");
//        }
//    }
//    public override void DisplayAccountInfo()
//    {
//        Console.WriteLine($"Account Number: {AccountNumber}");
//        Console.WriteLine($"Bank Account Type: {Account_type}");
//        Console.WriteLine($"Name: {Name}");
//        Console.WriteLine($"Balance: {Balance}");
//    }
//    public void ExecuteTransaction(double amount, string transaction_type)
//    {
//        if (transaction_type == "Deposit")
//        {
//            Deposit(amount);
//            PrintTransaction(amount, transaction_type);
//        }
//        else if (transaction_type == "Withdraw")
//        {
//            Withdraw(amount);
//            PrintTransaction(amount, transaction_type);
//        }
//    }

//    public void PrintTransaction(double amount, string transaction_type)
//    {

//        Console.WriteLine($"Account Number: {AccountNumber}");
//        Console.WriteLine($"Bank Account Type: {Account_type}");
//        Console.WriteLine($"Name: {Name}");
//        Console.WriteLine($"Balance  {transaction_type}ed: {amount}");
//        Console.WriteLine($"New Balance: {Balance}");
//    }

//}

//public class Bank
//{
//    public List<BankAccount> Customer_Account;
//    public Bank()
//    {
//        Customer_Account = new List<BankAccount>();
//    }

//    public void AddAccount(BankAccount bank_account)
//    {
//        Customer_Account.Add(bank_account);
//        bank_account.DisplayAccountInfo();
//    }

//    public void DepositToAccount(BankAccount bank_account, double Amount_Add)
//    {
//        bank_account.Deposit(Amount_Add);

//    }

//    public void WithdrawFromAccount(BankAccount bank_account, double Amount_DEL)
//    {

//        bank_account.Withdraw(Amount_DEL);

//    }
//    public void CheckAccount(BankAccount bank_account)
//    {

//        bank_account.DisplayAccountInfo();

//    }
//}

namespace BankManagement
{
    class Program
    {
        static void Main(string[] args)

        {
            Bank bank = new Bank();

            SavingsAcccount s_acc = new SavingsAcccount("Zain", 1, 98000, 12);
            CheckingAcccount c_acc = new CheckingAcccount("Osama", 2, 100000);
            BankAccount[] bank_accounts = { s_acc, c_acc };

            Console.WriteLine("---------------------------------Saving Account-------------------------------");
            bank.AddAccount(s_acc);
            Console.WriteLine();
            bank.DepositToAccount(s_acc, 2000);
            Console.WriteLine();
            bank.WithdrawFromAccount(s_acc, 5000);
            Console.WriteLine();

            Console.WriteLine("---------------------------------Checking Account-------------------------------");
            bank.AddAccount(c_acc);
            Console.WriteLine();
            bank.DepositToAccount(c_acc, 2000);
            Console.WriteLine();
            bank.WithdrawFromAccount(c_acc, 5000);
            Console.WriteLine();

            foreach (BankAccount account in bank_accounts)
            {

                account.DisplayAccountInfo();
            }


            //Console.WriteLine("---------------------------------Saving Account-------------------------------");
            //        bank.AddAccount(s_acc);
            //        Console.WriteLine();
            //        bank.DepositToAccount(s_acc, 2000);
            //        Console.WriteLine();
            //        bank.WithdrawFromAccount(s_acc, 5000);
            //        Console.WriteLine();
            //        bank.CheckAccount(s_acc);

            //Console.WriteLine("---------------------------------Checking Account-------------------------------");
            //bank.AddAccount(c_acc);
            //Console.WriteLine();
            //bank.DepositToAccount(c_acc, 2000);
            //Console.WriteLine();
            //bank.WithdrawFromAccount(c_acc, 5000);
            //Console.WriteLine();
            //bank.CheckAccount(c_acc);

            //Console.WriteLine(s_acc.Account_type);


        }
    }
}

    


