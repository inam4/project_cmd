﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagement
{
    //interface ITransaction
    //{
    //    void ExecuteTransaction(double amount, string transaction_type);
    //    void PrintTransaction(double amount, string transaction_type);
    //}
}
